rom django.shortcuts import render
from django.http import HttpResponse
from .models import movies
# Create your views here.

def index(request):
    obj = movies.objects.getAll()
    context={
        'title': obj.title,
        'year': obj.year

    }
    return render(request,'first_app/index.html',context)
